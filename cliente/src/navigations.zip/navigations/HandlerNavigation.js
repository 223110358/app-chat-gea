import { AuthNavigation } from './stacks';

import AppNavigation from './AppNavigation.js';

export function HandlerNavigation() {
    const user = {name:"Manuel"}; //TODO: cambiar por la logica de autenticacion
    return user ? <AppNavigation/> : <AuthNavigation/>
    
}