import { Text, View } from "react-native";

export function ChangeLastnameScreen() {
    return(
        <View>
            <Text>ChangeLastnameScreen</Text>
        </View>
    )
}
