import { Text, View } from "react-native";

export function CreateChatScreen() {
    return(
        <View>
            <Text>CreateChatScreen</Text>
        </View>
    )
}