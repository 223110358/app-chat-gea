import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    stackContent: {
        backgroundColor: "#1b28b3",
    },
    stackHeader: {
        backgroundColor: "#000000",
    },
    stackHeaderTitle: {
        color: "#c33333",
    },
    modalContent: {
        backgroundColor: "#1b28b3",

    },
    modalHeader: {
        backgroundColor: "#ee00de",
    },
    modalHeaderTitle: {
        color: "#ab1e1c",
    },

});