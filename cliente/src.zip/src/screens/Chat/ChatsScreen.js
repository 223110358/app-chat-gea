import { Text, View } from "react-native";

export function ChatsScreen() {
    return(
        <View>
            <Text>ChatsScreen</Text>
        </View>
    )
}