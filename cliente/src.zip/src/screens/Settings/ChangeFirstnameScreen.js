import { Text, View } from "react-native";

export function ChangeFirstnameScreen() {
    return(
        <View>
            <Text>ChangeFirstnameScreen</Text>
        </View>
    )
}
