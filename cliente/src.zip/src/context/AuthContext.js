import { createContext, useEffect, useState } from "react";

export const AuthContext = createContext();

export function AuthProvider(props) {
    const { children } = props;
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(null);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        // Aquí puedes cargar el estado de autenticación desde almacenamiento local o una API
        // Por ejemplo, podrías usar AsyncStorage para React Native
        (async () => {
            setLoading(false);
        })();
    }, []);
    const reLogin = async (refreshToken) => {
    };

    const login = async (accessToken) => {
    }
    const logout = async () => {
    }
    const updateUser = async (key, value) => {
    }
    const data = {
        accessToken: token,
        user:{name:"Manuel"},
        login,
        logout,
        updateUser
    };
    if (loading) {
        return null; // O un componente de carga
    }
    return (
        <AuthContext.Provider value={data}>
            {children}
        </AuthContext.Provider>
    );
}