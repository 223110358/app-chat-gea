import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    content: {
        flex: 1,
        margin:20,
        justifyContent: "center",
    },
    img: {
        width: "100%",
        height: 400,
        resizeMode: "contain",
        marginVertical:50,
    },
});