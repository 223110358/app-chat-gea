import { Text, View } from "react-native";

export function GroupsScreen() {
    return(
        <View>
            <Text>GroupsScreen</Text>
        </View>
    )
}