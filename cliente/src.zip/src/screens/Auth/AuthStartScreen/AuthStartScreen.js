import { Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { assets } from "../../../assets";
import { styles } from "./AuthStartScreen.style.js";

export function AuthStartScreen() {
    return(
        <SafeAreaView style={styles.content}>
          <Image source={assets.image.jpg.auth01} style={styles.img}/>
        </SafeAreaView>
    )
}